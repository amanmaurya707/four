package com.telecomapp.model;

public class FriendDTO {
	private Long phoneNumber;
	private Long friendPhoneNumber;
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Long getFriendPhoneNumber() {
		return friendPhoneNumber;
	}
	public void setFriendPhoneNumber(Long friendPhoneNumber) {
		this.friendPhoneNumber = friendPhoneNumber;
	}
	

	

}
